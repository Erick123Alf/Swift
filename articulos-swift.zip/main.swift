struct Articulo {
    let nombre: String
    let precio: Int
    var stock: Int
}

var articulos = [
    Articulo(nombre: "Zapatos", precio: 500, stock: 10),
    Articulo(nombre: "Playeras", precio: 340, stock: 40),
    Articulo(nombre: "Pantalones", precio: 100, stock: 100),
    Articulo(nombre: "Sombreros", precio: 40, stock: 15),
    Articulo(nombre: "Pantallas", precio: 5300, stock: 25),
]

var opcionIngresada: String = ""
var cuenta: Int = 0

while opcionIngresada != "2" {
    print("****Bienvenidos a Coppel****")
    print("****Articulos****")
    print("-----------------")

    for (index, articulo) in articulos.enumerated() {
        print("Articulo \(index + 1): \(articulo.nombre)")
        print("Precio: $\(articulo.precio)")
        print("Stock: \(articulo.stock)")
        print("______________________________")
    }

    print("1. Comprar Articulo")
    print("2. Salir")

    opcionIngresada = readLine() ?? ""

    switch opcionIngresada {
    case "1":
        print("Ingresa el numero de articulo (1-\(articulos.count)): ")
        guard let numArticulo = Int(readLine() ?? ""),
              numArticulo >= 1, numArticulo <= articulos.count else {
            print("Numero de articulo no valido!")
            break
        }

        let indice = numArticulo - 1
        print("Ingresa la cantidad a comprar: ")
        guard let cantidad = Int(readLine() ?? ""), cantidad > 0 else {
            print("Cantidad no valida!")
            break
        }

        if cantidad <= articulos[indice].stock {
            articulos[indice].stock -= cantidad
            let subtotal = articulos[indice].precio * cantidad
            cuenta += subtotal
            print("Agregado: \(cantidad) x \(articulos[indice].nombre) = $\(subtotal)")
            print("Total acumulado: $\(cuenta)")
        } else {
            print("Stock insuficiente. Disponible: \(articulos[indice].stock)")
        }

    case "2":
        print("Total a pagar: $\(cuenta)")
        print("Vuelve Pronto!!!")

    default:
        print("Opcion no valida!")
    }
}