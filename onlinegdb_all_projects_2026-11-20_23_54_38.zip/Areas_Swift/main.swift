import Foundation 

func calculaAreaCuadrado()
{
    print("\n ---Area del Cuadrado---")
    print("Ingresa un lado: ", terminator: "")
    
    if let input = readLine(), let lado = Double(input), lado > 0 
    {
        let area = lado * lado
        print("El area es: \(area)")
    }
    else
    {
        print("Error... Ingresa un numero valido")
    }
}

func calculaAreaRect()
{
    print("\n ---Area del Rectangulo---")
    print("Ingresa la base: ", terminator: "")
    
    guard let inputBase = readLine(), let base = Double(inputBase), base > 0 
    else
    {
        print("Error... Numero no valido")
        return
    }
    
    print("Ingresa la altura: ", terminator: "")
    
    guard let inputAltura = readLine(), let altura = Double(inputAltura), altura > 0
    else
    {
        print("Error... Numero no valido")
        return
    }
    
    let area = base * altura
    
    print("El area es: \(area)")
}

func calculaAreaTriangulo()
{
    print("\n ---Area del Triangulo---")
    print("Ingresa la base: ", terminator: "")
    guard let inputBase = readLine(), let base = Double(inputBase), base > 0 
    else
    {
        print("Error... Numero no valido")
        return
    }
    
    print("Ingresa la altura: ", terminator: "")
    guard let inputAltura = readLine(), let altura = Double(inputAltura), altura > 0 
    else
    {
        print("Error... Numero Invalido")
        return
    }
    
    let area = (base * altura) / 2.0
    
    print("El area es: \(area)")
}

func calculaAreaCirculo()
{
    print("\n ---Area del Circulo---")
    print("Ingresa el valor del radio: ", terminator: "")
    
    if let input = readLine(), let radio = Double(input), radio > 0 
    {
        let area = Double.pi * pow (radio, 2)
        print("El area es: \(area)")
    }
    else 
    {
        print("Error... Numero Invalido")
    }
}

var continuar = true

while continuar
{
    print("""
    
    =================================
       CÁLCULO DE ÁREAS GEOMÉTRICAS
    =================================
    1. Calcular área del Cuadrado
    2. Calcular área del Rectángulo
    3. Calcular área del Triángulo
    4. Calcular área del Círculo
    5. Salir
    ---------------------------------
    Selecciona una opción: 
    """, terminator: "")
    
    if let opcion = readLine() {
        switch opcion.trimmingCharacters(in: .whitespacesAndNewlines) {
        case "1":
            calculaAreaCuadrado()
        case "2":
            calculaAreaRect()
        case "3":
            calculaAreaTriangulo()
        case "4":
            calculaAreaCirculo()
        case "5":
            print("\nSalida!!!")
            continuar = false
        default:
            print("\n Opción no válida...")
        }
    }
}