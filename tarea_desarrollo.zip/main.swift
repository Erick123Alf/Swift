import Foundation

struct Articulo {
    let nombre: String
    let cantidad: Int
}

func registrarArticulos(inventario: inout [Articulo]) {
    print("\n--- 1. Registrar artículo ---")
    print("Por favor escriba la cantidad de tipos de artículos que desea ingresar: ", terminator: "")
    
    guard let entradaCantidad = readLine(), let totalArticulos = Int(entradaCantidad), totalArticulos > 0 else {
        print("Cantidad no válida. Regresando al menú...")
        return
    }
    
    print("\nRegistro de artículos")
    
    for i in 1...totalArticulos {
        print("\nArtículo \(i) - Ingrese el nombre: ", terminator: "")
        guard let nombre = readLine(), !nombre.isEmpty else {
            print("Nombre inválido. Se cancela el registro.")
            return
        }
        
        print("Artículo \(i) - Ingrese la cantidad: ", terminator: "")
        guard let entradaStock = readLine(), let cantidad = Int(entradaStock), cantidad >= 0 else {
            print("Cantidad inválida. Se cancela el registro.")
            return
        }
        
        let nuevoArticulo = Articulo(nombre: nombre, cantidad: cantidad)
        inventario.append(nuevoArticulo)
    }
    
    print("\n¡Artículos registrados con éxito!")
    print("Presione Enter para regresar al Menú Principal", terminator: "")
    let _ = readLine()
}

func verListaArticulos(inventario: [Articulo]) {
    print("\n--- 2. Ver lista de Artículos ---")
    
    if inventario.isEmpty {
        print("No hay artículos en el inventario.")
    } else {
        print("\nLista de productos:")
        for (index, articulo) in inventario.enumerated() {
            
            print("\(index + 1). Nombre: \(articulo.nombre) | Cantidad: \(articulo.cantidad)")
        }
    }
    
    print("\nPresione Enter para regresar al Menú Principal", terminator: "")
    let _ = readLine()
}

func consultarExistencia(inventario: [Articulo]) {
    print("\n--- 3. Consulta de artículos en existencia ---")
    
    if inventario.isEmpty {
        print("No hay existencias registradas.")
        print("Presione Enter para regresar al Menú Principal", terminator: "")
        let _ = readLine()
        return
    }
    
    print("Ingrese el nombre del artículo a buscar: ", terminator: "")
    guard let busqueda = readLine(), !busqueda.isEmpty else {
        print("Búsqueda inválida.")
        return
    }
    
    if let articuloEncontrado = inventario.first(where: { $0.nombre.lowercased() == busqueda.lowercased() }) {
        print("\n¡Artículo Encontrado!")
        print("Nombre: \(articuloEncontrado.nombre)")
        print("Cantidad en existencia: \(articuloEncontrado.cantidad)\n")
    } else {
        print("\nEl artículo '\(busqueda)' no existe en el inventario.\n")
    }
    
    print("Presione Enter para regresar al Menú Principal", terminator: "")
    let _ = readLine()
}

func iniciarPrograma() {
    var miInventario: [Articulo] = []
    var continuar = true
    
    while continuar {
        print("\n========== MENÚ ==========")
        print("1. Registrar Artículos")
        print("2. Ver Lista de Artículos")
        print("3. Consulta de Artículos")
        print("4. Salir")
        print("==========================")
        print("Elige una Opción: ", terminator: "")
        
        if let entrada = readLine(), let opcion = Int(entrada) {
            switch opcion {
            case 1:
                registrarArticulos(inventario: &miInventario)
            case 2:
                verListaArticulos(inventario: miInventario)
            case 3:
                consultarExistencia(inventario: miInventario)
            case 4:
                print("\nSaliendo del programa...")
                continuar = false
            default:
                print("\nOpción inválida. Intente de nuevo.")
            }
        } else {
            print("\nEntrada inválida... Seleccione un número.")
        }
    }
}


iniciarPrograma()